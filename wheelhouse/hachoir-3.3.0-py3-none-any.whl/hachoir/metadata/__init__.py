from hachoir.metadata.metadata import extractMetadata  # noqa

# Just import the module,
# each module use registerExtractor() method
import hachoir.metadata.archive  # noqa
import hachoir.metadata.audio  # noqa
import hachoir.metadata.file_system  # noqa
import hachoir.metadata.image  # noqa
import hachoir.metadata.jpeg  # noqa
import hachoir.metadata.misc  # noqa
import hachoir.metadata.program  # noqa
import hachoir.metadata.riff  # noqa
import hachoir.metadata.video  # noqa
import hachoir.metadata.cr2 # noqa