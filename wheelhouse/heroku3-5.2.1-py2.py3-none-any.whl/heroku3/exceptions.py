class InvalidNameException(Exception):
    pass