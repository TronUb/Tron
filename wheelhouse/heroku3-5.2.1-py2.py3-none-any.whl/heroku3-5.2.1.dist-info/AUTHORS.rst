Heroku3.py is written and maintained by Martin Moss and
various contributors:

Development Lead
````````````````

- Martin Moss <martin_moss@btinternet.com>

Based upon the original heroku.py by
````````````````````````````````````
- Kenneth Reitz <me@kennethreitz.com>
- johtso <johtso@gmail.com>
- skoczen <skoczen@gmail.com>
- You?
