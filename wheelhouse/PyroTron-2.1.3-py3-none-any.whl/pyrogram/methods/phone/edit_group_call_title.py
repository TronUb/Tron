from typing import Union, Optional

from pyrogram import raw



class EditGroupCallTitle:
    async def edit_group_call_title(
        self: "pyrogram.Client",
        chat_id: Union[int, str],
        title: str
    ) -> "pyrogram.raw.base.Updates":
        """ Edit a group call title
        """
        group_call = await self.get_group_call(chat_id)

        if group_call is None:
            return None

        call = group_call.call

        return await self.invoke(
            raw.functions.phone.EditGroupCallTitle(
                call=raw.types.InputGroupCall(
                    id=call.id,
                    access_hash=call.access_hash
                ),
                title=title
            )
        )
