KEYS = {
    "SPOTIFY_CLIENT_ID": "PLACEHOLDER_CLIENT_ID",  # Create an app from [here](https://developer.spotify.com/dashboard/applications)
    "SPOTIFY_CLIENT_SECRET": "PLACEHOLDER_CLIENT_SECRET",  # Create an app from [here](https://developer.spotify.com/dashboard/applications)
    "SPOTIFY_REDIRECT_URI": "http://localhost:5000/callback/spotify",  # You have to register this call back in your Application's dashboard https://developer.spotify.com/dashboard/applications
}
