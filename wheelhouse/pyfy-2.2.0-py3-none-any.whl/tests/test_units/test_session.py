# TODO: Test a new session is created when a new user is set
# TODO: Test max_retries, proxies, backoff_factor, cache are set to a session
